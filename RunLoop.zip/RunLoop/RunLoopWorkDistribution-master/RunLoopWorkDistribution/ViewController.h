//
//  ViewController.h
//  RunLoopWorkDistribution
//
//  Created by Di Wu on 9/19/15.
//  Copyright © 2015 Di Wu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

+ (void)task_1:(UITableViewCell *)cell indexPath:(NSIndexPath *)indexPath;
+ (void)task_2:(UITableViewCell *)cell indexPath:(NSIndexPath *)indexPath;
+ (void)task_3:(UITableViewCell *)cell indexPath:(NSIndexPath *)indexPath;
+ (void)task_4:(UITableViewCell *)cell indexPath:(NSIndexPath *)indexPath;
+ (void)task_5:(UITableViewCell *)cell indexPath:(NSIndexPath *)indexPath;

@end

