//
//  ViewController.h
//  006--方法懒加载
//
//  Created by H on 17/2/9.
//  Copyright © 2017年 TZ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

