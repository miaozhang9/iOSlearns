//
//  Pseron.h
//  006--方法懒加载
//
//  Created by H on 17/2/9.
//  Copyright © 2017年 TZ. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Pseron : NSObject
/** 年龄 */
@property(assign,nonatomic)int age;
@property(assign,nonatomic)int age1;
@end
