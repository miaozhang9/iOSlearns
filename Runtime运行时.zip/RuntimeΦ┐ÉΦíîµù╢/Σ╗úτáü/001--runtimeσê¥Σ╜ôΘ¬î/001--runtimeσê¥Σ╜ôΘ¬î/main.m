//
//  main.m
//  001--runtime初体验
//
//  Created by H on 17/2/7.
//  Copyright © 2017年 TZ. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "HKPerson.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        
        HKPerson * p = [[HKPerson alloc]init];
        
        
    }
    return 0;
}
