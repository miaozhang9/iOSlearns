//
//  NSURL+url.h
//  004--方法交换
//
//  Created by H on 17/2/7.
//  Copyright © 2017年 TZ. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSURL (url)
+(instancetype)HK_URLWithString:(NSString *)URLStirng;

@end
