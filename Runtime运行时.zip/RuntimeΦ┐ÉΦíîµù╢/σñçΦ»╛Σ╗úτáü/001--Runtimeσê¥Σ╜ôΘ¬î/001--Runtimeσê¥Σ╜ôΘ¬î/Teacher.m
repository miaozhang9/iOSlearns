//
//  Teacher.m
//  001--Runtime初体验
//
//  Created by H on 17/1/3.
//  Copyright © 2017年 H. All rights reserved.
//  做Oc 做不了的事情!!!

#import "Teacher.h"

@interface Teacher ()
/** 年龄 */
@property(assign,nonatomic)int age1;
@end

@implementation Teacher

@end
