//
//  main.m
//  003--KVO 底层实现原理
//
//  Created by H on 17/1/3.
//  Copyright © 2017年 H. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
