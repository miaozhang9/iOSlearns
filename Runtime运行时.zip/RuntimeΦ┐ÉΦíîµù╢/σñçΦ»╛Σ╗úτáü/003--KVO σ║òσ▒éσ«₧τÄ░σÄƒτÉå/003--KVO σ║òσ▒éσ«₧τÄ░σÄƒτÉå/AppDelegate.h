//
//  AppDelegate.h
//  003--KVO 底层实现原理
//
//  Created by H on 17/1/3.
//  Copyright © 2017年 H. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

